
URL to our website:

https://hub.coursera-apps.org/connect/sharedqzigwlbl

Link to our GitHub repo:

https://github.com/h-sarhan/UOL-Web-Dev-Team-Assignment/