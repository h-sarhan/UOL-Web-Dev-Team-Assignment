# Identification of purpose of web site to the appropriate stakeholders

## Owners

1. To help market their business and improve sales.
2. Increase ticket sales and revenue.
3. Reduce administrative costs by saving sales personnel time spent in ticket booking thus saving administration costs.

## Visitors

1. Booking in advance thus saving time for example standing in queues.
2. Finding about the address and phone numbers of theme park.
3. Obtaining information about the range of leisure activities available and their pricing in order to compare with other parks.

